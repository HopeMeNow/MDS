import math

def tj_cost(L, W):
    pass

def tj(L, W):
    pass

if __name__ == "__main__":
    W_example = ["jars", "jaws", "joke", "jury", "juxtaposition"]
    L_example = 15
    # should print 432
    print(tj_cost(L_example, W_example))
    # should print:
    #jars jaws
    #joke jury
    #juxtaposition
    print(tj(L_example, W_example))
