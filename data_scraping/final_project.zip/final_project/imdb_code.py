# define helper functions if needed
# and put them in `imdb_helper_functions` module.
# you can import them and use here like that:
import imdb_helper_functions as hp
import aiohttp
import asyncio
import functools
import queue


def get_actors_by_movie_soup(cast_page_soup, num_of_actors_limit=None):
    cast_table = cast_page_soup.find('table', attrs={'class': 'cast_list'})

    actors_links = []

    if not cast_table:
        return actors_links

    for link in cast_table.select('tr > td:nth-child(2) > a'):
        actors_links.append((link.text.strip(), link['href']))

    if num_of_actors_limit and num_of_actors_limit > 0:
        return actors_links[:num_of_actors_limit]
    return actors_links


def get_movies_by_actor_soup(actor_page_soup, url, num_of_movies_limit=None):
    filmography = hp.get_filmography_soup(actor_page_soup)

    films_list = []

    if not filmography:
        return films_list

    for film in filmography.find_all('div', attrs={'class': 'filmo-row'}):
        fiml_info_text = film.text.split('\n')
        if not fiml_info_text[5]:
            films_list.append((
                fiml_info_text[4],
                film.find('a', text=fiml_info_text[4])['href']
            ))

    if num_of_movies_limit and num_of_movies_limit > 0:
        return films_list[:num_of_movies_limit]
    return films_list


async def get_actor_neighbours_by_url(
    actor,
    session,
    actors,
    movies,
    num_of_actors_limit,
    num_of_movies_limit,
    verbose,
):
    actor_movies = actors.get(actor[0])
    if verbose:
        if actor_movies:
            print("Get actor's movies from cache\n")
        else:
            print("Get actor's movies from site\n")

    if not actor_movies:
        actor_soup = await hp.get_soup_by_url(actor[1], session)
        actor_movies = get_movies_by_actor_soup(actor_soup, actor[1], num_of_movies_limit)

        hp.update_hash([actor[0]], [actor_movies], actors, 'actors')

    actor_movies_urls = hp.list_of_pairs_to_urls(actor_movies)
    actor_movies_urls = list(map(lambda url: url + 'fullcredits', actor_movies_urls))

    movies_soups_or_actors = await hp.get_movie_soups_by_urls(actor_movies_urls, movies, session, verbose)
    neighbour_actors = list(map(
        lambda obj: obj if isinstance(obj, list) else get_actors_by_movie_soup(obj, num_of_actors_limit),
        movies_soups_or_actors
    ))

    hp.update_movies_hash(actor_movies_urls, neighbour_actors, movies)

    return list(set(functools.reduce(lambda a, b: a + b, neighbour_actors, [])))


async def get_movie_distance(
    actor_start_url,
    actor_end_url,
    max_depth=5,
    num_of_actors_limit=None,
    num_of_movies_limit=None,
    verbose=False,
):
    # check if we already have some data and restore it
    graph, actors, movies = hp.restore_cache(['graph', 'actors', 'movies'])

    # define session
    async with aiohttp.ClientSession() as session:
        # request start and end actors and check if they are already exist in graph
        start_actor_soup = await hp.get_soup_by_url(actor_start_url, session)
        end_actor_soup = await hp.get_soup_by_url(actor_end_url, session)

        start_actor_name = hp.get_actor_name_by_soup(start_actor_soup)
        end_actor_name = hp.get_actor_name_by_soup(end_actor_soup)

        if not start_actor_name or not end_actor_name:
            return None

        checked_actors = set()

        q = queue.Queue()
        q.put([(start_actor_name, actor_start_url)])

        depth = 0

        while not q.empty() and depth <= max_depth:
            current_path = q.get()
            depth = len(current_path) - 1

            if verbose:
                print('Queue length:', len(q.queue))
                print('Current depth:', depth)

            current_actor = current_path[-1]

            if current_actor[0] in checked_actors:
                continue

            if current_actor[0] == end_actor_name:
                path = hp.list_of_pairs_to_names(current_path)
                return len(path), path
            else:
                checked_actors.add(current_actor[0])
                next_neighbours = graph.get(current_actor[0])

                if verbose:
                    print(f'Current actor: {current_actor[0]}, url: {current_actor[1]}')

                if not next_neighbours:
                    try:
                        # list of tuples like (<actor name>, <actor page url>)
                        next_neighbours = await get_actor_neighbours_by_url(
                            current_actor,
                            session,
                            actors,
                            movies,
                            num_of_actors_limit,
                            num_of_movies_limit,
                            verbose,
                        )

                        hp.update_graph(graph, current_actor[0], next_neighbours)
                    except Exception as e:
                        print(f'Exception with {current_actor[0]}: ', e)
                        continue

                [
                    q.put([*current_path, neighbour])
                    for neighbour in next_neighbours
                ]

        return float('inf'), []


def get_movie_descriptions_by_actor_soup(actor_page_soup):
    # your code here
    return # your code here


# print(hp.test_get_actors_by_movie_soup(get_actors_by_movie_soup))
# print(hp.test_get_movies_by_actor_soup(get_movies_by_actor_soup))


res = asyncio.run(get_movie_distance(
    'https://www.imdb.com/name/nm0425005/',
    'https://www.imdb.com/name/nm1165110/',
    max_depth=3,
    verbose=True,
))
print(res)
